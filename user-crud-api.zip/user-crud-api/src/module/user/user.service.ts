import { Injectable, NotFoundException } from '@nestjs/common';
import { User } from './entities/user.entity';
import { CreateUserDto } from './dto/create-user.dto';
@Injectable()
export class UsersService {
  private users: User[] = [];
  private idCounter = 1;

  create(user: CreateUserDto): User {
    const newUser: User = {
      id: this.idCounter++,
      name: user.name,
      email: user.email,
    };
    this.users.push(newUser);
    return newUser;
  }

  findAll(): User[] {
    return this.users;
  }
}